from django.apps import AppConfig


class GroceryPlannerAppConfig(AppConfig):
    name = 'grocery_planner_app'
